export default {
    root: {
        class: 'relative'
    },
    mask: {
        class: 'bg-black/40'
    }
};
